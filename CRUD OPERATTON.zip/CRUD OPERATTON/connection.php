 <?php
        $conn = new mysqli('localhost','root','','emp_db');

        if(!$conn){
            die(mysqli_error($conn));
        }
        // else{
        //     echo "connection successfully";
        // }
?> 

